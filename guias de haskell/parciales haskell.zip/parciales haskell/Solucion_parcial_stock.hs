-- Ejercicio 1
quitar::(Eq t)=> t ->[t] -> [t]
quitar elemento [x] | elemento/=x = [x]
                    | otherwise = []
quitar elemento (x:xs) | elemento/=x = x:quitar elemento xs
                       | otherwise = quitar elemento xs
contarProductoEnStock :: [Char]->[[Char]]->Int
contarProductoEnStock producto [x] | producto==x = 1
                                   | otherwise = 0
contarProductoEnStock producto (x:xs) | producto==x = 1+contarProductoEnStock producto xs
                                      | otherwise= contarProductoEnStock producto xs
generarStock :: [[Char]]->[([Char],Int)] 
generarStock [[]] = []
generarStock [x] = [(x,contarProductoEnStock x [x])]
generarStock (x:xs) | xs/=[] = (x,contarProductoEnStock x (x:xs)):generarStock (quitar x ((x:xs)))
                    | otherwise = [(x,contarProductoEnStock x (x:xs))]

-- Ejercicio 2
stockDeProducto :: [([Char],Int)] -> [Char] -> Int
stockDeProducto [] producto = 0
stockDeProducto [(x,y)] producto | producto==x = y
                                 | otherwise = 0
stockDeProducto ((x,y):xs) producto | producto==x = y
                                    | otherwise = stockDeProducto xs producto

-- [("papa",2),("Melon",4),("Sandia",8),("Palta",56),("Cerdo",12),("Limon",20),("manzana",3)]

-- Ejercicio 3
buscarPrecioProducto :: [Char] -> [([Char],Float)] -> Float
buscarPrecioProducto producto [] = 0.0
buscarPrecioProducto producto [(x,y)] | producto==x = y
                                      | otherwise = 0.0
buscarPrecioProducto producto ((x,y):xs) | producto==x = y
                                         | otherwise = buscarPrecioProducto producto xs
dineroEnStock :: [([Char],Int)]->[([Char],Float)]->Float
dineroEnStock ((x,y):xs) precios | xs/=[] = fromIntegral(stockDeProducto ((x,y):xs) x)*(buscarPrecioProducto x precios)+dineroEnStock xs precios
                                 | otherwise = fromIntegral(y)*(buscarPrecioProducto x precios)

-- Ejercicio 4
aplicarOferta :: [([Char],Int)]->[([Char],Float)]->[([Char],Float)]
aplicarOferta [(x,y)] precios | y>10= [(x,(buscarPrecioProducto x precios)*0.8)]
                              | otherwise = [(x,buscarPrecioProducto x precios)]
aplicarOferta ((x,y):xs) precios | (stockDeProducto ((x,y):xs) x)>10 = (x,(buscarPrecioProducto x precios)*0.8):aplicarOferta xs precios
                                 | otherwise = (x,buscarPrecioProducto x precios):aplicarOferta xs precios