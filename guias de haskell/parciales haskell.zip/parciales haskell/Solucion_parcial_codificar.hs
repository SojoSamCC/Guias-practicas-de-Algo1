--Ejercicio 1
hayQueCodificar :: Char -> [(Char,Char)] -> Bool
hayQueCodificar c [(x,y)] = c==x 
hayQueCodificar c ((x,y):xs) | c==x = True
                             | otherwise = hayQueCodificar c (tail((x,y):xs))

--Ejercicio 2
contarEnFrase :: Char -> [Char] -> Int
contarEnFrase c [x] | c==x = 1
                    | otherwise = 0
contarEnFrase c (x:xs) | c==x = 1+contarEnFrase c xs
                       | otherwise = contarEnFrase c xs

cuantasVecesHayQueCodificar :: Char -> [Char] -> [(Char,Char)] -> Int
cuantasVecesHayQueCodificar _ _ [] = 0
cuantasVecesHayQueCodificar c frase mapeo | (hayQueCodificar c mapeo)==False = 0
                                          | otherwise = contarEnFrase c frase

--Ejercicio 3
todosDiferentes :: [Char] -> Bool
todosDiferentes [x,y] | x/=y = True
                      | otherwise = False

todosDiferentes (x:xs) = x/=head xs && todosDiferentes xs
todosIguales :: [Char] -> Bool
todosIguales [x,y] | x==y = True
                   | otherwise = False
todosIguales (x:xs) = x==(head xs) && todosIguales xs

quitar :: Char -> [Char] -> [Char]
quitar c [x] | c==x = []
             | otherwise = [x]
quitar c (x:xs) | c==x = quitar c xs
                | otherwise = x:quitar c xs

laQueMasHayQueCodificar :: [Char] -> [(Char,Char)] -> Char 
laQueMasHayQueCodificar frase mapeo | (todosIguales frase)==True || (todosDiferentes frase)==True = head frase
                                    | cuantasVecesHayQueCodificar (head frase) frase mapeo < cuantasVecesHayQueCodificar (head (tail frase)) frase mapeo = laQueMasHayQueCodificar (tail frase) mapeo
                                    | otherwise = laQueMasHayQueCodificar (quitar (head (tail frase)) frase) mapeo

-- Ejercicio 4
devolverCodigo :: Char->[(Char,Char)]->Char
devolverCodigo _ [(x,y)] = y
devolverCodigo c ((x,y):xs) | c==x = y
                            | otherwise = devolverCodigo c xs
codificarFrase :: [Char] -> [(Char,Char)]->[Char]
codificarFrase [x] mapeo | (hayQueCodificar x mapeo)==True = [devolverCodigo x mapeo]
                         | otherwise = [x]
codificarFrase (x:xs) mapeo | (hayQueCodificar x mapeo)==True = (devolverCodigo x mapeo):codificarFrase xs mapeo
                            | otherwise = x:codificarFrase xs mapeo
                            
