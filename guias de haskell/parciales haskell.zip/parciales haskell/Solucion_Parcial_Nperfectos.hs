-- Ejercicio 1
divisoresPropiosAux :: Int -> Int -> [Int]
divisoresPropiosAux n contador | contador==n = []
                               | contador<n && mod n contador==0 = contador:divisoresPropiosAux n (contador+1)
                               | otherwise = divisoresPropiosAux n (contador+1)
divisoresPropios :: Int -> [Int]
divisoresPropios n = divisoresPropiosAux n 1

-- Ejercicio 2
sumatoria :: [Int] -> Int
sumatoria [] = 0
sumatoria (x:xs) | xs/=[] = x+sumatoria xs
                 | otherwise = x
sonAmigos :: Int->Int->Bool
sonAmigos n m = (sumatoria (divisoresPropios n)==m) && (sumatoria (divisoresPropios m)==n)

-- Ejercicio 3
quitar :: (Eq t)=> t ->[t] -> [t]
quitar _ [] = []
quitar elemento (x:xs) | elemento/=x = x:quitar elemento xs
                       | otherwise = quitar elemento xs
ultimo :: [Int] ->Int
ultimo (x:xs) | xs==[] = x
              | otherwise = ultimo xs
reverso :: [Int] -> [Int]
reverso (x:xs) | xs/=[] = (ultimo (x:xs)):reverso (quitar (ultimo (x:xs)) (x:xs))
               | otherwise = [x]
losPrimerosNPerfectosAux :: Int -> [Int]
losPrimerosNPerfectosAux n | n==1 = [1]
                           | sumatoria (divisoresPropios n)==n = n:losPrimerosNPerfectosAux (n-1)
                           | otherwise = losPrimerosNPerfectosAux (n-1)
losPrimerosNPerfectos :: Int -> [Int]
losPrimerosNPerfectos n = reverso (losPrimerosNPerfectosAux n)

-- Ejercicio 4
buscarAmigo :: Int -> [Int] -> Int
buscarAmigo _ [] = 0
buscarAmigo n (x:xs) | (sonAmigos n x)==True && n/=x = x
                     | otherwise = buscarAmigo n xs
-- [220,1,3,4,6,284]
listaAmigosAux :: [Int] -> [(Int,Int)]
listaAmigosAux [] = []
listaAmigosAux (x:xs) | xs/=[] = (x,buscarAmigo x (quitar x (x:xs))):listaAmigosAux xs
                      | otherwise = [(x,buscarAmigo x (quitar x (x:xs)))]

esTuplanula :: (Int,Int) -> Bool
esTuplanula (x,y) = y==0

sacarTuplaRepetida :: [(Int,Int)] -> [(Int,Int)]
sacarTuplaRepetida [] = []
sacarTuplaRepetida [(x,y)] | (esTuplanula ((x,y))) == True = []
                           | otherwise = [(x,y)]
sacarTuplaRepetida ((x,y):xs) | (esTuplanula ((x,y))) == False = (x,y):sacarTuplaRepetida xs
                              | otherwise = sacarTuplaRepetida xs

listaAmigos :: [Int] -> [(Int,Int)]
listaAmigos lista = sacarTuplaRepetida (listaAmigosAux lista)