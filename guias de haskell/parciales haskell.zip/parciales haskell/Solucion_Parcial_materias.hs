-- Ejercicio 1
contadorMateriasAprobadas :: [Int] -> Int
contadorMateriasAprobadas [x] | x>=4 =1
                              | otherwise = 0
contadorMateriasAprobadas (x:xs) | x>=4 =1+contadorMateriasAprobadas xs
                                 | otherwise = 0+contadorMateriasAprobadas xs
aproboMasDeNMaterias :: [([Char],[Int])]->[Char]->Int->Bool
aproboMasDeNMaterias ((x,notas):xs) alumno n | alumno==x = contadorMateriasAprobadas notas >= n 
                                             | otherwise = aproboMasDeNMaterias xs alumno n

-- Ejercicio 2
aplazo :: [Int] -> Bool
aplazo [x] = x<4
aplazo (x:xs) | x>=4 = aplazo xs
              | otherwise = True
largo :: (Eq t)=>[t] -> Int
largo (x:xs) | xs/=[] = 1+largo xs
             | otherwise = 1
sumatoria :: [Int] -> Int
sumatoria (x:xs) | xs/=[] = x+sumatoria xs
                 | otherwise = x

promedio :: [Int] ->Float
promedio [] = 0.0
promedio [x] = fromIntegral x
promedio (x:xs) = fromIntegral(sumatoria (x:xs))/fromIntegral(largo (x:xs))

buenosAlumnos :: [([Char],[Int])]->[[Char]] 
buenosAlumnos [(alumno,notas)] | (aplazo notas)==False && promedio notas >=8 = [alumno]
                               | otherwise = []
buenosAlumnos ((alumno,notas):xs) | (aplazo notas)==False && promedio notas >=8 = alumno:buenosAlumnos xs
                                  | otherwise = buenosAlumnos xs

-- Ejercicio 3
quitar :: ([Char],[Int])->[([Char],[Int])]->[([Char],[Int])]
quitar c [d] | c==d = []
             | otherwise = [d]
quitar c (x:xs) | c==x = quitar c xs
                | otherwise = x:quitar c xs

mejorPromedio :: [([Char],[Int])]->[Char]
mejorPromedio [(alumno1,notas1),(alumno2,notas2)] | promedio notas1 >= promedio notas2 = alumno1
                                                  | otherwise = alumno2
mejorPromedio (x:xs) | promedio (snd x) >= promedio (snd (head xs)) = mejorPromedio (x:tail xs)
                     | promedio (snd x) < promedio (snd (head xs)) = mejorPromedio xs

-- Ejericicio 4
-- Lo dejo hasta acá porque no puedo ver el resto del ejercicio, no aparece en la foto.