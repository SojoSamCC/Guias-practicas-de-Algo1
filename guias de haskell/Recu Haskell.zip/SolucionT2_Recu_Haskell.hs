module SolucionT2 where
  
type Fila = [Int]
type Tablero = [Fila]
type Posicion = (Int,Int)
type Camino = [Posicion]

-- Funciones útiles ------------------------------------------

quitar :: (Eq t)=> t -> [t] -> [t]
quitar elemento [] = []
quitar elemento (x:xs) | elemento/=x = x:quitar elemento xs
                       | otherwise = quitar elemento xs
quitar2 :: (Eq t)=> t -> [t] -> [t]
quitar2 elemento [] = []
quitar2 elemento (x:xs) | elemento/=x = x:quitar2 elemento xs
                        | otherwise = xs
ultimo :: (Eq t, Num t)=> [t] -> t
ultimo [x] = x
ultimo (x:xs) | xs==[] = x
              | otherwise = ultimo xs
ultimo2 :: (Eq t, Num t)=> [[t]] -> [t]
ultimo2 [[x]] = [x]
ultimo2 ((x:xs):as) | as==[] = (x:xs)
                    | xs==[] = ultimo2 as
                    | otherwise = ultimo2 (xs:as)
ultimoPosta ::(Eq t, Num t)=>[[t]]-> t
ultimoPosta [] = 0
ultimoPosta [(x:xs)] = ultimo (x:xs)
ultimoPosta ((x:xs):as) = ultimo (ultimo2 ((x:xs):as))

seRepite :: Int->Int->[Int]->Bool
seRepite _ 2 _ = True
seRepite elemento contador [x] | elemento==x && contador==1 = True 
                               | otherwise = False
seRepite elemento contador (x:xs) | elemento==x = seRepite elemento (contador+1) xs
                                  | otherwise = seRepite elemento contador xs

sacarRepetidos :: [Int] -> [Int]
sacarRepetidos [] = []
sacarRepetidos [x] = [x]
sacarRepetidos (x:xs) | (seRepite x 0 (x:xs))==True = x:sacarRepetidos (quitar x (x:xs))
                      | otherwise = x:sacarRepetidos xs

largo :: [Int] -> Int 
largo [x] =1
largo (x:xs) | xs/=[] =1+largo xs
             | otherwise =1

--------------------------------------------------------------

-- Ejercicio 1
minimoFila :: Int->[Int] -> Int
minimoFila elemento [x] | elemento<=x = elemento
                        | otherwise = x
minimoFila elemento (x:xs) | elemento<= x = minimoFila elemento xs
                           | otherwise = minimoFila x xs 

evaluarFilas :: [[Int]] -> [Int]
evaluarFilas [(x:xs)] = [minimoFila x (x:xs)]
evaluarFilas ((x:xs):as) | as/=[] = (minimoFila x (x:xs)):evaluarFilas as  
                         | otherwise = [minimoFila x (x:xs)]
minimo :: Tablero -> Int
minimo t = minimoFila (head (evaluarFilas t)) (evaluarFilas t)

-- Ejercicio 2

seRepiteEnFilas :: Int->Int->[[Int]] -> Bool
seRepiteEnFilas _ 2 _ = True
seRepiteEnFilas elemento contador [[x]] | elemento==x && contador==1 = True
                                        | otherwise = False
seRepiteEnFilas elemento contador ((x:xs):as) | contador>=2 = True
                                              | contador<=1 && as==[] && xs==[] && elemento==x = seRepiteEnFilas elemento (contador+1) as
                                              | contador<=1 && as==[] && xs==[] && elemento/=x = False
                                              | xs==[] && elemento==x = seRepiteEnFilas elemento (contador+1) as
                                              | xs==[] && elemento/=x = seRepiteEnFilas elemento (contador) as
                                              | xs/=[] && elemento==x = seRepiteEnFilas elemento (contador+1) (xs:as)
                                              | otherwise = seRepiteEnFilas elemento contador (xs:as)

repetidosAux :: [[Int]]->[Int]
repetidosAux [[x]] = []
repetidosAux ((x:xs):as) | xs/=[] && (seRepiteEnFilas x 0 ((x:xs):as))==True = x:repetidosAux (xs:as)
                         | xs/=[] && (seRepiteEnFilas x 0 ((x:xs):as))==False = repetidosAux (xs:as)
                         | xs==[] && (seRepiteEnFilas x 0 ((x:xs):as))==False = repetidosAux as
                         | otherwise = x:repetidosAux as

repetidos :: Tablero -> [Int] 
repetidos t = sacarRepetidos (repetidosAux t)

-- Ejercicio 3
fila :: Int -> Int -> Tablero -> Fila
fila contador numeroFila ((x:xs):as) | contador<numeroFila = fila (contador+1) numeroFila as
                                     | otherwise = (x:xs)

buscarFila :: Tablero ->Posicion -> Fila
buscarFila t p = fila 1 (fst(p)) t 

columna :: Int -> Int -> Fila -> Int
columna contador numeroColumna (x:xs) | contador<numeroColumna = columna (contador+1) numeroColumna xs
                                      | otherwise = x 

buscarColumna :: Fila -> Posicion -> Int
buscarColumna f p = columna 1 (snd(p)) f

valoresDeCamino :: Tablero -> Camino -> [Int]
valoresDeCamino t [] = []
valoresDeCamino t [x] = [buscarColumna (buscarFila t x) x]
valoresDeCamino t (x:xs) | xs/=[] = (buscarColumna (buscarFila t x) x):valoresDeCamino t xs
                         | otherwise = [buscarColumna (buscarFila t x) x]

-- Ejercicio 4

evaluarAPartir :: Int -> Int ->[Int]-> [Int]
evaluarAPartir i contador (x:xs) | contador<i = evaluarAPartir i (contador+1) xs
                                 | otherwise = (x:xs)

esSecuenciaPar :: [Int] -> Bool
esSecuenciaPar [x] = x==1
esSecuenciaPar [x,1] = mod x 2 ==0
esSecuenciaPar (x:xs) = mod x 2 == 0 && esSecuenciaPar xs

hacerCollatzDe :: Int -> [Int]
hacerCollatzDe 1 = [1]
hacerCollatzDe n | mod n 2 == 0 = (div n 2):hacerCollatzDe (div n 2)
                 | otherwise = ((3*n)+1):hacerCollatzDe ((3*n)+1)
                 
esCaminoCollatz :: [Int] -> Int -> Bool 
esCaminoCollatz [] _ = False
esCaminoCollatz [x] i | i>1 || x/=1 = False
                      | otherwise = x==1
esCaminoCollatz (x:xs) i | (i>largo (x:xs))= False
                         | (evaluarAPartir i 1 (x:xs))==(head (evaluarAPartir i 1 (x:xs))):(quitar2 (ultimo (hacerCollatzDe (head (evaluarAPartir i 1 (x:xs))))) (hacerCollatzDe (head (evaluarAPartir i 1 (x:xs))))) = True
                         | otherwise = False